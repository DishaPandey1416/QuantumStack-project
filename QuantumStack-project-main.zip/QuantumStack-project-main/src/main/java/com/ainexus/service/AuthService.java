package com.ainexus.service;

import com.ainexus.dto.*;
import com.ainexus.model.*;
import com.ainexus.repository.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.*;
import java.util.*;

@Service
public class AuthService {

    private final UserRepository users;
    private final AuthTokenRepository tokens;
    private final PasswordEncoder encoder;
    private final SecureRandom random = new SecureRandom();

    public AuthService(UserRepository u, AuthTokenRepository t, PasswordEncoder e) {
        users = u;
        tokens = t;
        encoder = e;
    }

    @Transactional
    public Map<String, Object> register(RegisterRequest r) {
        String email = r.getEmail().trim().toLowerCase();

        if (users.existsByEmail(email)) {
            throw new IllegalArgumentException(
                    "An account with this email already exists."
            );
        }

        User u = users.save(
                new User(
                        r.getName().trim(),
                        email,
                        encoder.encode(r.getPassword()),
                        "STUDENT"
                )
        );

        return loginUser(u, "Account created successfully.");
    }

    @Transactional
    public Map<String, Object> login(LoginRequest r) {
        User u = users.findByEmail(
                r.getEmail().trim().toLowerCase()
        ).orElseThrow(() ->
                new IllegalArgumentException(
                        "Invalid email or password."
                )
        );

        if (!encoder.matches(r.getPassword(), u.getPassword())) {
            throw new IllegalArgumentException(
                    "Invalid email or password."
            );
        }

        return loginUser(u, "Login successful.");
    }

    private Map<String, Object> loginUser(User u, String message) {
        tokens.deleteByUser(u);

        byte[] b = new byte[32];
        random.nextBytes(b);

        String token = Base64.getUrlEncoder()
                .withoutPadding()
                .encodeToString(b);

        tokens.save(
                new AuthToken(
                        token,
                        u,
                        LocalDateTime.now().plusHours(12)
                )
        );

        Map<String, Object> m = new LinkedHashMap<>();
        m.put("message", message);
        m.put("token", token);
        m.put(
                "user",
                Map.of(
                        "id", u.getId(),
                        "name", u.getName(),
                        "email", u.getEmail(),
                        "role", u.getRole()
                )
        );

        return m;
    }

    public User authenticate(String header) {
        if (header == null || !header.startsWith("Bearer ")) {
            throw new IllegalArgumentException(
                    "Authentication required."
            );
        }

        AuthToken t = tokens.findByTokenValue(
                header.substring(7)
        ).orElseThrow(() ->
                new IllegalArgumentException(
                        "Invalid or expired session."
                )
        );

        if (t.getExpiresAt().isBefore(LocalDateTime.now())) {
            tokens.delete(t);
            throw new IllegalArgumentException(
                    "Session expired. Please login again."
            );
        }

        return t.getUser();
    }

    public void logout(String header) {
        if (header != null && header.startsWith("Bearer ")) {
            tokens.findByTokenValue(
                    header.substring(7)
            ).ifPresent(tokens::delete);
        }
    }
}
